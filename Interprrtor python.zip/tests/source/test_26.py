def main():
    a = 5
    b = 5

    if a == b:
        a += 1
        b -= 1

    if b == 4:
        b = a
        a = b
