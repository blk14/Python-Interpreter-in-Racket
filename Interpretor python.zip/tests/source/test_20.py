def main():
	a = "ana"
	b = (1, 2, 3)

	c = 2 + 3
	d = 4
	e = 5

	f = d + e
	g = d - e
	h = e % d
