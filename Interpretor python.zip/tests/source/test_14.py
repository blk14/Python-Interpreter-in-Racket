def main(a, b):
	d = b
	a = 3
	b = 2
	c = a + b
	d = c - a
	return c
