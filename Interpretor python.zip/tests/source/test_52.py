def main():
	s = 0
	for x in range(10):
		for y in range(10):
			s += (x + y)
