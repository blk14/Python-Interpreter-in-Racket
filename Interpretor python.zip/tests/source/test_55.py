def main():
	x = sqrt(9)
	y = sqrt(16)
	s = x + y
