def main():
	a = 2
	b = 3
	c = 5

	f = 20
	g = 21
	h = 22
	j = 23

	x1 = f % a
	x2 = g % b
	x3 = h % c
	x4 = j % b

	y1 = f % b
	y2 = g % a
